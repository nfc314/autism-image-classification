# Bundled data

- [`processed-eye-strips.zip`](processed-eye-strips.zip) contains the cropped Training, Validation, and Test images. Cell 3 uses only Training and Validation. No data upload or manual extraction is needed in Colab.
- [`evaluation/test-eye-strips.zip`](evaluation/test-eye-strips.zip) contains the same Test images as the processed archive. Cell 4 uses this smaller ZIP for evaluation and the optional pixel-sensitivity heatmap.
- Before fitting a new model, the notebook checks Training and Validation for exact pixel matches with the held-out Test strips. This does not detect different photos of the same child.

Git is configured to ignore these data archives. See the [project README](../README.md#find-the-data) for the source, attribution, and privacy guidance. Check permission before sharing eye strips or raw photos.
