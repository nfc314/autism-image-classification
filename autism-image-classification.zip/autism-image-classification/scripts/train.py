"""Train and evaluate the Physics 580 model from preprocessed eye strips."""

from __future__ import annotations

import argparse
import copy
import json
import math
from collections.abc import Sequence
from importlib.metadata import version
from pathlib import Path
from typing import TYPE_CHECKING

import joblib
import numpy as np
from sklearn.decomposition import PCA
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    roc_auc_score,
)
from sklearn.preprocessing import StandardScaler

if TYPE_CHECKING:
    from torch import nn

from features import image_paths, load_features
from model import (
    CONFUSION_MATRIX_FILENAME,
    DEFAULT_COMPONENTS,
    DEFAULT_HIDDEN_UNITS,
    FORMAT_VERSION,
    MODEL_FILENAME,
    PCA_FILENAME,
    SCALER_FILENAME,
    SCORE_THRESHOLD,
    build_model,
)

REPO_ROOT = Path(__file__).resolve().parent.parent
SPLITS = {"train": "Training Data", "test": "Test", "validation": "Validation Data"}
TRAINING_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
ARTIFACT_NAMES = (
    MODEL_FILENAME, PCA_FILENAME, SCALER_FILENAME, CONFUSION_MATRIX_FILENAME
)


def load_split(
    data_dir: Path,
    split_name: str,
    positive_class: str | None = None,
    negative_class: str | None = None,
    expected_shape: tuple[int, int] | None = None,
) -> tuple[np.ndarray, np.ndarray, tuple[int, int]]:
    """Load a split using path-based labels or explicit class folders."""
    split_dir = data_dir / split_name
    if not split_dir.is_dir():
        raise FileNotFoundError(f"Missing split directory: {split_dir}")
    if (positive_class is None) != (negative_class is None):
        raise ValueError("Specify both strict class folders, or neither.")
    labels_by_dir = None
    if positive_class is not None and negative_class is not None:
        labels_by_dir = {positive_class.casefold(): 1, negative_class.casefold(): 0}

    paths = sorted(
        (path for path in image_paths(split_dir)
         if path.suffix.lower() in TRAINING_EXTENSIONS),
        key=lambda path: path.relative_to(split_dir).parts,
    )
    labels_in_path_order = []
    for path in paths:
        relative = path.relative_to(split_dir)
        if labels_by_dir is None:
            # Apply the substring rule to the filename and split-relative folders, but
            # exclude outer folders so moving the repository cannot alter labels.
            label = int(not any("non" in part.lower() for part in relative.parts))
        else:
            label = labels_by_dir.get(relative.parts[0].casefold())
            if len(relative.parts) < 2 or label is None:
                raise ValueError(
                    f"{relative} in {split_name!r} is not under a recognized class "
                    f"folder. Expected {positive_class!r} or {negative_class!r}."
                )
        labels_in_path_order.append(label)

    labels = np.asarray(labels_in_path_order, dtype=np.int64)
    counts = np.bincount(labels, minlength=2)
    if not counts.all():
        raise ValueError(
            f"{split_name!r} needs at least one eye strip in each class. "
            f"Found {counts[1]} positive and {counts[0]} negative."
        )
    # Read in sorted path order (which determines the inferred training shape),
    # then assemble the matrix with positives followed by negatives.
    rows, image_shape = load_features(paths, expected_shape)
    order = np.concatenate((np.flatnonzero(labels == 1), np.flatnonzero(labels == 0)))
    return rows[order], labels[order], image_shape


def prepare_features(
    train_rows: np.ndarray,
    val_rows: np.ndarray,
    test_rows: np.ndarray | None,
    num_inputs: int,
) -> tuple[PCA, StandardScaler, np.ndarray, np.ndarray, np.ndarray | None]:
    """Fit transformations only on the training split, then reuse them."""
    if num_inputs > min(train_rows.shape):
        raise ValueError(
            f"{num_inputs} components requested; training data support at most "
            f"{min(train_rows.shape)}. Add training samples or lower --components."
        )

    pca = PCA(n_components=num_inputs, svd_solver="randomized", random_state=42)
    train_pca = pca.fit_transform(train_rows)
    test_pca = pca.transform(test_rows) if test_rows is not None else None
    val_pca = pca.transform(val_rows)
    scaler = StandardScaler()
    train_features = scaler.fit_transform(train_pca).astype(np.float32)
    val_features = scaler.transform(val_pca).astype(np.float32)
    test_features = scaler.transform(test_pca).astype(np.float32) if test_pca is not None else None
    return pca, scaler, train_features, val_features, test_features


def fit_model(
    train_features: np.ndarray,
    train_labels: np.ndarray,
    val_features: np.ndarray,
    val_labels: np.ndarray,
    hidden_units: int,
    epochs: int,
    patience: int,
    learning_rate: float,
) -> tuple[nn.Sequential, int, float]:
    """Use full-batch Adam and keep the weights with lowest validation loss."""
    import torch
    from torch import nn

    model = build_model(train_features.shape[1], hidden_units)
    train_x = torch.from_numpy(train_features)
    val_x = torch.from_numpy(val_features)
    train_y = torch.as_tensor(train_labels, dtype=torch.float32).reshape(-1, 1)
    val_y = torch.as_tensor(val_labels, dtype=torch.float32).reshape(-1, 1)
    loss_fn = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    best_loss = math.inf
    best_weights = None
    best_epoch = 0

    for epoch in range(1, epochs + 1):
        model.train()
        optimizer.zero_grad()
        loss = loss_fn(model(train_x), train_y)
        if not torch.isfinite(loss).item():
            raise ValueError(f"Non-finite training loss at epoch {epoch}.")
        loss.backward()
        optimizer.step()

        model.eval()
        with torch.no_grad():
            val_loss = loss_fn(model(val_x), val_y).item()

        if not math.isfinite(val_loss):
            raise ValueError(f"Non-finite validation loss at epoch {epoch}.")
        if val_loss < best_loss:
            best_loss = val_loss
            best_epoch = epoch
            best_weights = copy.deepcopy(model.state_dict())

        if epoch % 10 == 0 or epoch == 1 or epoch == epochs:
            print(f"Epoch {epoch}: training {loss.item():.4f}, validation {val_loss:.4f}")
        if epoch - best_epoch >= patience:
            print("Stopped because validation loss stopped improving.")
            break

    if best_weights is None:
        raise RuntimeError("Training did not produce a model checkpoint.")
    model.load_state_dict(best_weights)
    model.eval()
    return model, best_epoch, best_loss


def evaluate(
    model: nn.Sequential, test_features: np.ndarray, labels: np.ndarray
) -> tuple[np.ndarray, dict]:
    """Evaluate the selected checkpoint once on the independent test split."""
    import torch

    model.eval()
    with torch.no_grad():
        scores = torch.sigmoid(model(torch.from_numpy(test_features))).numpy().ravel()
    predictions = (scores >= SCORE_THRESHOLD).astype(np.int64)
    cm = confusion_matrix(labels, predictions, labels=[0, 1])
    tn, fp, fn, tp = map(int, cm.ravel())
    counts = np.bincount(labels, minlength=2)
    metrics = {
        "accuracy": float(accuracy_score(labels, predictions)),
        "balanced_accuracy": float(balanced_accuracy_score(labels, predictions)),
        "roc_auc": float(roc_auc_score(labels, scores)),
        "test_class_counts": {"negative": int(counts[0]), "positive": int(counts[1])},
        "majority_class_baseline": float(counts.max() / labels.size),
        "false_positive_rate": fp / (tn + fp),
        "specificity": tn / (tn + fp),
        "false_negative_rate": fn / (tp + fn),
        "sensitivity": tp / (tp + fn),
        "confusion_matrix": cm.tolist(),
        "score_threshold": SCORE_THRESHOLD,
    }
    return cm, metrics


def save_sensitivity_plot(
    model: nn.Sequential,
    val_features: np.ndarray,
    pca: PCA,
    scaler: StandardScaler,
    image_shape: tuple[int, int],
    output_path: Path,
) -> None:
    """Save mean absolute validation logit gradients in normalized pixel space."""
    import matplotlib
    import torch

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    model.eval()
    total = np.zeros(image_shape, dtype=np.float64)
    for i, row in enumerate(val_features, start=1):
        features = torch.tensor(row[None, :], dtype=torch.float32, requires_grad=True)
        gradient = torch.autograd.grad(model(features).sum(), features)[0]
        gradient = gradient.detach().cpu().numpy()[0]
        pixel_gradient = (gradient / scaler.scale_) @ pca.components_
        total += np.abs(pixel_gradient.reshape(image_shape))
        if i % 25 == 0 or i == len(val_features):
            print(f"Computed pixel sensitivity for {i}/{len(val_features)} validation strips.")
    mean_absolute = np.abs(total / len(val_features))

    fig, ax = plt.subplots(figsize=(8, 3), constrained_layout=True)
    heatmap = ax.imshow(mean_absolute, cmap="jet", vmin=0,
                        vmax=max(float(mean_absolute.max()), 1e-12))
    fig.colorbar(heatmap, ax=ax, label="Mean absolute logit gradient")
    ax.set_title(f"Pixel sensitivity across {len(val_features)} validation images")
    ax.set_axis_off()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=REPO_ROOT / "data" / "Processed Data (Eye Strip)")
    parser.add_argument("--artifacts-dir", type=Path, default=REPO_ROOT / "outputs" / "retrained")
    parser.add_argument("--output-dir", type=Path, default=REPO_ROOT / "outputs" / "retrained")
    parser.add_argument("--positive-class", help="positive folder name (requires --negative-class)")
    parser.add_argument("--negative-class", help="negative folder name (requires --positive-class)")
    parser.add_argument("--components", type=int, default=DEFAULT_COMPONENTS)
    parser.add_argument("--hidden-units", type=int, default=DEFAULT_HIDDEN_UNITS)
    parser.add_argument("--epochs", type=int, default=400)
    parser.add_argument("--patience", type=int, default=50)
    parser.add_argument("--learning-rate", type=float, default=0.001)
    parser.add_argument("--seed", type=int, help="optional PyTorch initialization seed")
    parser.add_argument("--skip-sensitivity", action="store_true")
    parser.add_argument(
        "--fit-only", action="store_true",
        help="Fit on Training Data and select on Validation Data without loading or evaluating Test.",
    )
    parser.add_argument(
        "--overwrite-artifacts", action="store_true", help="replace saved artifacts"
    )
    args = parser.parse_args(argv)

    positive, negative = args.positive_class, args.negative_class
    if (positive is None) != (negative is None):
        parser.error("--positive-class and --negative-class must be provided together.")
    if positive is not None and negative is not None:
        if positive.casefold() == negative.casefold() or any(
            not name.strip() or name in (".", "..") or "/" in name or "\\" in name
            for name in (positive, negative)
        ):
            parser.error("Use two distinct class subfolder names, not paths.")
    if min(args.components, args.hidden_units, args.epochs, args.patience) < 1:
        parser.error("--components, --hidden-units, --epochs and --patience must be positive.")
    if not math.isfinite(args.learning_rate) or args.learning_rate <= 0:
        parser.error("--learning-rate must be finite and positive.")

    if args.fit_only and (args.artifacts_dir / CONFUSION_MATRIX_FILENAME).exists():
        parser.error("Use a new artifact directory for --fit-only; it does not produce a confusion matrix.")
    existing = [name for name in ARTIFACT_NAMES if (args.artifacts_dir / name).exists()]
    if existing and not args.overwrite_artifacts:
        parser.error(
            f"{args.artifacts_dir} already contains {', '.join(existing)}. "
            "Choose another --artifacts-dir or use --overwrite-artifacts."
        )
    return args


def main() -> None:
    args = parse_args()
    import torch

    if args.seed is not None:
        torch.manual_seed(args.seed)

    data = {}
    image_shape = None
    for split, folder in SPLITS.items():
        if args.fit_only and split == "test":
            continue
        rows, labels, image_shape = load_split(
            args.data_dir, folder, args.positive_class, args.negative_class, image_shape
        )
        data[split] = rows, labels
        print(f"{folder}: {len(rows)} strips, class counts {np.bincount(labels).tolist()}")
    assert image_shape is not None

    train_rows, train_labels = data["train"]
    val_rows, val_labels = data["validation"]
    test_rows, test_labels = data.get("test", (None, None))
    pca, scaler, train_features, val_features, test_features = prepare_features(
        train_rows, val_rows, test_rows, args.components
    )
    model, best_epoch, best_loss = fit_model(
        train_features,
        train_labels,
        val_features,
        val_labels,
        args.hidden_units,
        args.epochs,
        args.patience,
        args.learning_rate,
    )
    if args.fit_only:
        cm = None
        metrics = {"evaluation_split": None, "fit_split": "Training Data",
                   "checkpoint_selection_split": "Validation Data"}
    else:
        assert test_features is not None and test_labels is not None
        cm, metrics = evaluate(model, test_features, test_labels)
    metrics.update(
        {
            "best_epoch": best_epoch,
            "best_validation_loss": best_loss,
            "seed": args.seed,
            "pca_components": args.components,
            "hidden_units": args.hidden_units,
            "max_epochs": args.epochs,
            "patience": args.patience,
            "learning_rate": args.learning_rate,
            "dependency_versions": {
                package: version(package) for package in ("torch", "numpy", "scikit-learn", "joblib")
            },
            "class_folders": (
                {"negative": args.negative_class, "positive": args.positive_class}
                if args.positive_class is not None else None
            ),
            "image_shape": list(image_shape),
        }
    )
    args.artifacts_dir.mkdir(parents=True, exist_ok=True)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    torch.save(
        {
            "format_version": FORMAT_VERSION,
            "num_inputs": args.components,
            "hidden_units": args.hidden_units,
            "image_shape": list(image_shape),
            "state_dict": model.state_dict(),
        },
        args.artifacts_dir / MODEL_FILENAME,
    )
    for name, obj in (
        (PCA_FILENAME, pca),
        (SCALER_FILENAME, scaler),
    ):
        joblib.dump(obj, args.artifacts_dir / name)
    if cm is not None:
        joblib.dump(cm, args.artifacts_dir / CONFUSION_MATRIX_FILENAME)
    metrics_text = json.dumps(metrics, indent=2) + "\n"
    (args.output_dir / "training_metrics.json").write_text(metrics_text, encoding="utf-8")
    print(metrics_text)
    if not args.skip_sensitivity:
        save_sensitivity_plot(
            model, val_features, pca, scaler, image_shape,
            args.output_dir / "pixel_sensitivity.png",
        )
    print(f"Saved artifacts to {args.artifacts_dir} and reports to {args.output_dir}.")


if __name__ == "__main__":
    try:
        main()
    except (FileNotFoundError, ValueError) as error:
        raise SystemExit(f"Training failed: {error}") from None
