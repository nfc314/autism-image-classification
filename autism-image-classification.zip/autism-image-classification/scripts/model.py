"""Shared PyTorch architecture and checkpoint names."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from torch import nn

MODEL_FILENAME = "model.pt"
PCA_FILENAME = "pca.joblib"
SCALER_FILENAME = "scaler.joblib"
CONFUSION_MATRIX_FILENAME = "confusion_matrix.joblib"
FORMAT_VERSION = 1
DEFAULT_HIDDEN_UNITS = 60
DEFAULT_COMPONENTS = 17
SCORE_THRESHOLD = 0.5


def build_model(
    num_inputs: int, hidden_units: int = DEFAULT_HIDDEN_UNITS
) -> nn.Sequential:
    """Build a one-hidden-layer network; the output is one logit."""
    from torch import nn

    return nn.Sequential(
        nn.Linear(num_inputs, hidden_units),
        nn.ReLU(),
        nn.Linear(hidden_units, 1),
    )
