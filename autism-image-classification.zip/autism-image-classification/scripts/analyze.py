"""Report held-out Test metrics and, optionally, a heatmap of the same test images."""

import argparse
import csv
import json
from pathlib import Path

import joblib
from sklearn.metrics import confusion_matrix

from model import SCORE_THRESHOLD
from predict import load_model, resolve_legacy_model, score_features
from train import SPLITS, load_split, save_sensitivity_plot


def load_inputs(artifacts, crops, split, use_legacy):
    legacy = resolve_legacy_model(artifacts, "" if use_legacy else None)
    model, expected_shape = load_model(artifacts, legacy)
    pca = joblib.load(artifacts / "pca.joblib")
    scaler = joblib.load(artifacts / "scaler.joblib")
    rows, labels, image_shape = load_split(
        crops, SPLITS[split], "Autistic", "Non-Autistic", expected_shape
    )
    return model, pca, scaler, rows, labels, image_shape


def evaluate_test(artifacts, crops, output, use_legacy, include_heatmap=False):
    model, pca, scaler, rows, labels, shape = load_inputs(
        artifacts, crops, "test", use_legacy
    )
    _, predictions = score_features(rows, model, pca, scaler)
    cm = confusion_matrix(labels, predictions, labels=[0, 1])
    tn, fp, fn, tp = map(int, cm.ravel())

    metrics = {
        "split": "Test",
        "n_scored": int(labels.size),
        "score_threshold": SCORE_THRESHOLD,
        "tn": tn, "fp": fp, "fn": fn, "tp": tp,
        "accuracy": (tp + tn) / labels.size,
        "sensitivity": tp / (tp + fn),
        "specificity": tn / (tn + fp),
    }
    (output / "classification_metrics.json").write_text(
        json.dumps(metrics, indent=2) + chr(10), encoding="utf-8"
    )
    with (output / "confusion_matrix.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["Actual / Predicted", "Positive result", "Negative result"])
        writer.writerow(["Has autism", tp, fn])
        writer.writerow(["Does not have autism", fp, tn])

    if include_heatmap:
        save_test_heatmap(model, pca, scaler, rows, shape, output)


def save_test_heatmap(model, pca, scaler, rows, shape, output):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    import torch

    features = scaler.transform(pca.transform(rows)).astype("float32")
    model.eval()
    total = np.zeros(shape, dtype=np.float64)
    for row in features:
        x = torch.tensor(row[None, :], dtype=torch.float32, requires_grad=True)
        grad_pc = torch.autograd.grad(model(x).sum(), x)[0].detach().cpu().numpy()[0]
        grad_pixels = (grad_pc / scaler.scale_) @ pca.components_
        total += np.abs(grad_pixels.reshape(shape))

    mean_absolute = np.abs(total / len(features))
    fig, ax = plt.subplots(figsize=(8, 3), constrained_layout=True)
    plot = ax.imshow(mean_absolute, cmap="jet", vmin=0,
                     vmax=max(float(mean_absolute.max()), 1e-12))
    fig.colorbar(plot, ax=ax, label="Mean absolute logit gradient")
    ax.set_title(f"Pixel sensitivity across {len(features)} Test images")
    ax.set_axis_off()
    fig.savefig(output / "pixel_sensitivity.png", dpi=160)
    plt.close(fig)


def validation_heatmap(artifacts, crops, output, use_legacy):
    model, pca, scaler, rows, _, image_shape = load_inputs(
        artifacts, crops, "validation", use_legacy
    )
    features = scaler.transform(pca.transform(rows)).astype("float32")
    save_sensitivity_plot(model, features, pca, scaler, image_shape,
                              output / "pixel_sensitivity.png")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("test", "heatmap"))
    parser.add_argument("artifacts", type=Path)
    parser.add_argument("crops", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--saved-project-model", action="store_true",
                        help="Load the trusted whole-model checkpoint from the artifacts directory.")
    parser.add_argument("--include-heatmap", action="store_true",
                        help="Plot sensitivity using the same model and images as the Test metrics.")
    args = parser.parse_args()
    if args.include_heatmap and args.mode != "test":
        parser.error("--include-heatmap requires the test mode.")
    try:
        args.output.mkdir(parents=True, exist_ok=True)
        if args.mode == "test":
            evaluate_test(args.artifacts, args.crops, args.output,
                          args.saved_project_model, args.include_heatmap)
        else:
            validation_heatmap(args.artifacts, args.crops, args.output, args.saved_project_model)
    except (OSError, ValueError, ImportError) as error:
        parser.exit(1, f"Analysis failed: {error}\n")


if __name__ == "__main__":
    main()
