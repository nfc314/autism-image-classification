"""Find, align, and save 128 × 20 grayscale eye strips from raw photos."""

from __future__ import annotations

import argparse
from collections.abc import Iterator
import csv
from dataclasses import dataclass
import math
from pathlib import Path
import tempfile
from urllib.request import urlretrieve

import numpy as np

MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/face_landmarker/"
    "face_landmarker/float16/1/face_landmarker.task"
)
REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_INPUT_DIR = REPO_ROOT / "data" / "Unprocessed Data"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "data" / "Processed Data (Eye Strip)"
DEFAULT_MODEL_PATH = REPO_ROOT / "artifacts" / "face_landmarker.task"
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
CROP_WIDTH = 128
CROP_HEIGHT = 20
EYE_SPACING_RATIO = 0.7
LEFT_IRIS_CENTER = 468
RIGHT_IRIS_CENTER = 473
MIN_EAR = 0.21
NUM_FACES_TO_DETECT = 5
MIN_DETECTION_CONFIDENCE = 0.35
MIN_FACE_PRESENCE_CONFIDENCE = 0.35


@dataclass(frozen=True)
class CropResult:
    source_path: Path
    crop_path: Path


@dataclass(frozen=True)
class CropOutcome:
    """One usable BGR crop or one reason a source/face was skipped."""

    source_path: Path
    crop: np.ndarray | None = None
    issue: str | None = None
    face_index: int | None = None


def image_sources(input_path: Path, *, exclude_dir: Path | None = None) -> list[Path]:
    """List the supported input files, optionally excluding an output subtree."""
    if input_path.is_file():
        if input_path.suffix.lower() not in IMAGE_EXTENSIONS:
            raise ValueError(f"Unsupported image extension: {input_path.suffix}")
        return [input_path]
    if not input_path.is_dir():
        raise FileNotFoundError(f"Input photo or folder does not exist: {input_path}")

    excluded = exclude_dir.resolve() if exclude_dir is not None else None
    input_root = input_path.resolve()
    if excluded == input_root:
        raise ValueError("The input folder and crop output directory must be different.")
    if excluded is not None and not excluded.is_relative_to(input_root):
        excluded = None
    return sorted(
        path for path in input_path.rglob("*")
        if path.suffix.lower() in IMAGE_EXTENSIONS and path.is_file()
        and (excluded is None or not path.resolve().is_relative_to(excluded))
    )


def resolve_landmarker_asset(model_path: Path | None) -> Path:
    if model_path is not None:
        path = Path(model_path).expanduser()
        if not path.is_file():
            raise FileNotFoundError(f"Face Landmarker model does not exist: {path}")
        return path

    path = DEFAULT_MODEL_PATH
    if not path.is_file():
        path.parent.mkdir(parents=True, exist_ok=True)
        # Leave no incomplete model at the cache path if the download fails.
        with tempfile.NamedTemporaryFile(dir=path.parent, suffix=".task", delete=False) as tmp:
            temporary_path = Path(tmp.name)
        try:
            urlretrieve(MODEL_URL, temporary_path)
            temporary_path.replace(path)
        finally:
            temporary_path.unlink(missing_ok=True)
    return path


def eye_aspect_ratio(face_landmarks, image_shape, corners, vertical_pairs) -> float:
    height, width = image_shape[:2]

    def xy(index):
        point = face_landmarks[index]
        return point.x * width, point.y * height

    def distance(index_a, index_b):
        x1, y1 = xy(index_a)
        x2, y2 = xy(index_b)
        return math.hypot(x2 - x1, y2 - y1)

    eye_width = distance(*corners)
    if eye_width < 1e-6:
        return 0.0
    vertical_opening = sum(distance(a, b) for a, b in vertical_pairs)
    return vertical_opening / (2 * eye_width)


def eyes_are_open(face_landmarks, image_shape) -> bool:
    left_ear = eye_aspect_ratio(
        face_landmarks, image_shape,
        corners=(33, 133),
        vertical_pairs=((160, 144), (158, 153)),
    )
    right_ear = eye_aspect_ratio(
        face_landmarks, image_shape,
        corners=(362, 263),
        vertical_pairs=((385, 380), (387, 373)),
    )
    return left_ear >= MIN_EAR and right_ear >= MIN_EAR


def eye_centers(face_landmarks, image_shape):
    # Iris landmarks require MediaPipe's 478-point face mesh.
    if len(face_landmarks) <= RIGHT_IRIS_CENTER:
        return None
    height, width = image_shape[:2]
    centers = [
        [face_landmarks[i].x * width, face_landmarks[i].y * height]
        for i in (LEFT_IRIS_CENTER, RIGHT_IRIS_CENTER)
    ]
    return sorted(centers, key=lambda point: point[0])


def aligned_eye_crop(image, face_landmarks):
    import cv2

    centers = eye_centers(face_landmarks, image.shape)
    if centers is None:
        return None

    (x1, y1), (x2, y2) = centers
    eye_distance = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
    target_eye_distance = CROP_WIDTH * EYE_SPACING_RATIO
    if eye_distance < target_eye_distance:
        return None

    midpoint = ((x1 + x2) / 2, (y1 + y2) / 2)
    angle_degrees = math.degrees(math.atan2(y2 - y1, x2 - x1))
    matrix = cv2.getRotationMatrix2D(midpoint, angle_degrees, target_eye_distance / eye_distance)
    matrix[0, 2] += CROP_WIDTH / 2 - midpoint[0]
    matrix[1, 2] += CROP_HEIGHT / 2 - midpoint[1]
    return cv2.warpAffine(
        image, matrix, (CROP_WIDTH, CROP_HEIGHT),
        flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT_101,
    )


def face_area(face_landmarks, image_shape) -> float:
    height, width = image_shape[:2]
    xs = [point.x * width for point in face_landmarks]
    ys = [point.y * height for point in face_landmarks]
    return (max(xs) - min(xs)) * (max(ys) - min(ys))


def find_faces(image, landmarker):
    import cv2
    import mediapipe as mp

    rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
    return landmarker.detect(mp_image).face_landmarks


def _make_landmarker(model_path: Path | None):
    import mediapipe as mp

    asset_path = resolve_landmarker_asset(model_path)
    options = mp.tasks.vision.FaceLandmarkerOptions(
        base_options=mp.tasks.BaseOptions(model_asset_path=str(asset_path)),
        running_mode=mp.tasks.vision.RunningMode.IMAGE,
        num_faces=NUM_FACES_TO_DETECT,
        min_face_detection_confidence=MIN_DETECTION_CONFIDENCE,
        min_face_presence_confidence=MIN_FACE_PRESENCE_CONFIDENCE,
    )
    return mp.tasks.vision.FaceLandmarker.create_from_options(options)


def _make_glasses_classifier():
    from glasses_detector import GlassesClassifier

    return GlassesClassifier()


def _read_photo(path: Path):
    import cv2

    # Keep the notebook's OpenCV path-I/O behavior wherever it works.
    try:
        image = cv2.imread(str(path))
    except cv2.error:
        image = None
    if image is not None:
        return image

    # Retain a byte-based fallback for Windows paths OpenCV may reject.
    encoded = path.read_bytes()
    if not encoded:
        return None
    return cv2.imdecode(np.frombuffer(encoded, dtype=np.uint8), cv2.IMREAD_COLOR)


def _to_gray(crop: np.ndarray) -> np.ndarray:
    import cv2

    return cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)


def _encode_gray_jpeg(gray: np.ndarray) -> bytes | None:
    import cv2

    ok, encoded = cv2.imencode(".jpg", gray)
    return encoded.tobytes() if ok else None


def encode_gray_crop(crop: np.ndarray) -> bytes | None:
    """Encode the grayscale eye strip with the cropper's default JPEG settings."""
    return _encode_gray_jpeg(_to_gray(crop))


def _save_gray_crop(path: Path, crop: np.ndarray) -> bool:
    import cv2

    gray = _to_gray(crop)
    try:
        if cv2.imwrite(str(path), gray):
            return True
    except cv2.error:
        pass

    encoded = _encode_gray_jpeg(gray)
    if encoded is None:
        return False
    path.write_bytes(encoded)
    return True


def _detect_crops(
    sources: list[Path], model_path: Path | None, all_faces: bool,
) -> Iterator[CropOutcome]:
    classifier = _make_glasses_classifier()
    with _make_landmarker(model_path) as landmarker:
        for source in sources:
            face_index = None
            try:
                image = _read_photo(source)
                if image is None:
                    yield CropOutcome(source, issue="Could not read image")
                    continue
                if classifier(source, format="bool"):
                    yield CropOutcome(source, issue="Glasses")
                    continue
                faces = sorted(
                    find_faces(image, landmarker),
                    key=lambda face: face_area(face, image.shape), reverse=True,
                )
                if not faces:
                    yield CropOutcome(source, issue="No face detected")
                    continue

                for face_index, face in enumerate(faces if all_faces else faces[:1], start=1):
                    if not eyes_are_open(face, image.shape):
                        yield CropOutcome(
                            source, issue="Eyes closed or too narrow", face_index=face_index,
                        )
                        continue
                    crop = aligned_eye_crop(image, face)
                    if crop is None:
                        yield CropOutcome(source, issue="Could not create crop", face_index=face_index)
                        continue
                    yield CropOutcome(source, crop=crop, face_index=face_index)
            except Exception as error:
                # Detector/crop errors for an individual file should not lose the batch.
                yield CropOutcome(source, issue=f"{type(error).__name__}: {error}",
                                  face_index=face_index)


def iter_crops(
    input_path: Path,
    *,
    model_path: Path | None = None,
    all_faces: bool = False,
    exclude_dir: Path | None = None,
) -> Iterator[CropOutcome]:
    """Detect eyes in one photo or a folder without writing crops or reports."""
    input_path = Path(input_path).expanduser()
    if exclude_dir is not None:
        exclude_dir = Path(exclude_dir).expanduser()
    sources = image_sources(input_path, exclude_dir=exclude_dir)
    if not sources:
        raise ValueError(f"No supported raw images found in {input_path}")
    return _detect_crops(sources, model_path, all_faces)


def _crop_destination(
    output_folder: Path, source: Path, face_suffix: str, used: set[str]
) -> Path:
    path = output_folder / f"{source.stem}{face_suffix}.jpg"
    count = 2
    while path.as_posix().casefold() in used:
        path = output_folder / f"{source.stem}_{count}{face_suffix}.jpg"
        count += 1
    used.add(path.as_posix().casefold())
    return path


def preprocess_images(
    input_path: Path,
    output_dir: Path,
    *,
    model_path: Path | None = None,
    all_faces: bool = False,
) -> list[CropResult]:
    """Write eye strips and a detection_review.csv; return this run's saved crops only."""
    input_path = Path(input_path).expanduser()
    output_dir = Path(output_dir).expanduser()
    outcomes = iter_crops(
        input_path, model_path=model_path, all_faces=all_faces, exclude_dir=output_dir,
    )

    output_dir.mkdir(parents=True, exist_ok=True)
    used: set[str] = set()
    saved: list[CropResult] = []
    input_root = input_path if input_path.is_dir() else input_path.parent

    with (output_dir / "detection_review.csv").open("w", newline="", encoding="utf-8") as report:
        writer = csv.writer(report)
        writer.writerow(("image_path", "issue"))
        for outcome in outcomes:
            source = outcome.source_path
            relative = source.relative_to(input_root)
            if outcome.crop is None:
                writer.writerow((relative, outcome.issue))
                continue
            try:
                folder = output_dir / relative.parent
                folder.mkdir(parents=True, exist_ok=True)
                suffix = f"_eyes_face{outcome.face_index}" if all_faces else "_eyes"
                destination = _crop_destination(folder, source, suffix, used)
                if _save_gray_crop(destination, outcome.crop):
                    saved.append(CropResult(source, destination))
                else:
                    writer.writerow((relative, "Could not save crop"))
            except Exception as error:
                writer.writerow((relative, f"{type(error).__name__}: {error}"))

    return saved


def _preview_crops(crops: list[CropResult], count: int):
    import matplotlib.pyplot as plt
    from PIL import Image

    for item in crops[:count]:
        with Image.open(item.crop_path) as crop:
            _, axis = plt.subplots(figsize=(6, 3))
            axis.imshow(crop, cmap="gray", vmin=0, vmax=255)
            axis.set_title(item.crop_path.name)
            axis.axis("off")
    if crops:
        plt.show()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "input", type=Path, nargs="?", default=DEFAULT_INPUT_DIR,
        help="One raw photo or a directory of raw photos (default: Unprocessed Data/)",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR,
        help="Destination for eye strips (default: Processed Data (Eye Strip)/)",
    )
    parser.add_argument("--landmarker-model", type=Path, help="Use an existing Face Landmarker model")
    parser.add_argument("--all-faces", action="store_true", help="Crop every face, not only the largest")
    parser.add_argument("--preview", action="store_true", help="Show up to eight saved eye strips")
    args = parser.parse_args()

    try:
        crops = preprocess_images(
            args.input, args.output_dir,
            model_path=args.landmarker_model, all_faces=args.all_faces,
        )
    except (ValueError, OSError, ImportError) as error:
        parser.exit(1, f"Preprocessing error: {error}\n")
    print(f"Saved {len(crops)} eye strips to {args.output_dir}.")
    print(f"Review log: {args.output_dir.expanduser() / 'detection_review.csv'}")
    if args.preview:
        _preview_crops(crops, 8)


if __name__ == "__main__":
    main()
