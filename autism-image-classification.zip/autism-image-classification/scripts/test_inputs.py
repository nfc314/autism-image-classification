"""Stage raw Test archives or organize pre-cropped splits for analysis."""

import argparse
from pathlib import Path, PurePosixPath
from shutil import copyfileobj
import shutil
from tempfile import TemporaryFile
from zipfile import BadZipFile, ZipFile

from prepare_dataset import (
    MAX_IMAGE_BYTES, MAX_TOTAL_BYTES, SPLITS, key, plan_entries, safe_parts,
)

TEST_SPLIT = "Test"


def extract_test(archive, output, prefix=(), depth=0):
    images, nested = plan_entries(archive, prefix)
    selected = [(info, path) for info, path in images if path.parts[0] == TEST_SPLIT]
    if not selected and not images and not nested and not prefix:
        images, _ = plan_entries(archive, ("Test",))
        selected = [(info, path) for info, path in images if path.parts[0] == TEST_SPLIT]

    if not selected:
        test_archives = [
            info for info in nested
            if SPLITS.get(key(PurePosixPath(safe_parts(info)[-1]).stem)) == TEST_SPLIT
        ]
        if len(test_archives) > 1:
            raise ValueError("More than one test ZIP was found.")
        if depth >= 2 or (not test_archives and len(nested) != 1):
            raise ValueError("No test folders or Test.zip found in the selected archive.")
        member = (test_archives or nested)[0]
        if member.file_size > MAX_TOTAL_BYTES:
            raise ValueError("The nested dataset ZIP exceeds the size limit.")
        with TemporaryFile() as buffer, archive.open(member) as source:
            copyfileobj(source, buffer)
            buffer.seek(0)
            with ZipFile(buffer) as child:
                return extract_test(child, output, ("Test",) if test_archives else prefix, depth + 1)

    targets = set()
    labels = set()
    total = 0
    for info, relative in selected:
        destination = relative.as_posix().casefold()
        if destination in targets:
            raise ValueError("Two test images map to the same destination.")
        targets.add(destination)
        labels.add(relative.parts[1])
        total += info.file_size
        if info.file_size > MAX_IMAGE_BYTES or total > MAX_TOTAL_BYTES:
            raise ValueError("Test images exceed the extraction size limit.")
    if labels != {"Autistic", "Non-Autistic"}:
        raise ValueError("The test split must contain both class folders.")

    for info, relative in selected:
        path = output.joinpath(*relative.parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        with archive.open(info) as source, path.open("xb") as target:
            copyfileobj(source, target)
    return len(selected)


CLASSES = {"autistic", "nonautistic"}
STRIP_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def class_key(name):
    return "".join(char for char in name.casefold() if char.isalnum())


def has_class_folders(path):
    return path.is_dir() and CLASSES <= {
        class_key(entry.name) for entry in path.iterdir() if entry.is_dir()
    }


def find_original_split(folder, split):
    names = ({"test", "testdata", "testing", "testingdata"} if split == "Test" else
             {"validation", "validationdata", "val", "valdata", "valid", "validdata"})
    other = {"train", "training", "trainingdata", "traindata", "test", "testdata",
             "testing", "testingdata", "validation", "validationdata", "val", "valdata",
             "valid", "validdata"} - names
    matches = [p for p in folder.rglob("*")
               if class_key(p.name) in names and has_class_folders(p)]
    if not matches:
        matches = [p for p in [folder, *folder.iterdir()]
                   if class_key(p.name) not in other and has_class_folders(p)]
    if len(matches) != 1:
        raise ValueError(f"Choose a ZIP with one cropped {split} split containing "
                         "Autistic and Non-Autistic subfolders.")
    return matches[0]


def index_strips(root):
    indexed = {}
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in STRIP_EXTENSIONS:
            continue
        relative = path.relative_to(root)
        if len(relative.parts) < 2 or class_key(relative.parts[0]) not in CLASSES:
            continue
        key = "/".join([class_key(relative.parts[0]),
                        *(part.casefold() for part in relative.parts[1:])])
        if key in indexed:
            raise ValueError("Two crops have the same relative filename.")
        indexed[key] = path
    return indexed


def stage_scoring_strips(strips, crops, split):
    # Keep image bytes unchanged; normalize only the class directory spelling.
    labels = {"autistic": "Autistic", "nonautistic": "Non-Autistic"}
    if {key.split("/", 1)[0] for key in strips} != set(labels):
        raise ValueError("The requested split needs at least one eye strip in each class.")
    for key, source in strips.items():
        label, relative = key.split("/", 1)
        parts = source.parts[-len(relative.split("/")):]
        target = (crops / split / labels[label]).joinpath(*parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("raw-test", "cropped-test", "cropped-validation"))
    parser.add_argument("source", type=Path, help="Raw ZIP or extracted cropped folder.")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    try:
        if args.mode == "raw-test":
            with ZipFile(args.source) as archive:
                count = extract_test(archive, args.output)
            print(f"Prepared {count:,} raw Test images.")
        else:
            split = "Test" if args.mode == "cropped-test" else "Validation Data"
            strips = index_strips(find_original_split(args.source, split))
            stage_scoring_strips(strips, args.output, split)
            print(f"Prepared {len(strips):,} cropped {split} images.")
    except (BadZipFile, OSError, RuntimeError, ValueError) as error:
        parser.exit(1, f"Could not prepare inputs: {error}\n")


if __name__ == "__main__":
    main()
