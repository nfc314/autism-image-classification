"""Plot a hypothetical repeated-classification example using Bayes' rule."""
import argparse
import csv
from pathlib import Path

import joblib
import numpy as np
from scipy.stats import binom

ROOT = Path(__file__).resolve().parent.parent


def rates_from_confusion_matrix(cm):
    matrix = np.asarray(cm, dtype=float)
    if matrix.shape != (2, 2) or not np.isfinite(matrix).all() or (matrix < 0).any():
        raise ValueError("Expected a 2x2 confusion matrix of nonnegative counts.")
    tn, fp, fn, tp = matrix.ravel()
    if (tn + fp) == 0 or (tp + fn) == 0:
        raise ValueError("The confusion matrix must include both reference classes.")
    return tp / (tp + fn), tn / (tn + fp)


def posterior_curve(n, sensitivity, specificity, prevalence):
    if n < 1:
        raise ValueError("Set --n-images to a positive integer.")
    if not 0 < prevalence < 1:
        raise ValueError("Set --prevalence strictly between 0 and 1.")
    if not (0 <= sensitivity <= 1 and 0 <= specificity <= 1):
        raise ValueError("Sensitivity and specificity must be between 0 and 1.")
    k = np.arange(n + 1)
    log_pos = binom.logpmf(k, n, sensitivity)
    log_neg = binom.logpmf(k, n, 1 - specificity)
    a = np.log(prevalence) + log_pos
    b = np.log1p(-prevalence) + log_neg
    total = np.logaddexp(a, b)
    posterior = np.full(k.shape, np.nan)
    possible = np.isfinite(total)
    posterior[possible] = np.exp(a[possible] - total[possible])
    return k, np.exp(log_pos), np.exp(log_neg), posterior


def plot_curve(k, pos, neg, posterior, output, color_scale):
    import matplotlib.pyplot as plt
    from matplotlib.cm import ScalarMappable
    from matplotlib.colors import LogNorm, Normalize

    cmap = plt.get_cmap("viridis").copy()
    cmap.set_bad("lightgray")
    positive = posterior[np.isfinite(posterior) & (posterior > 0)]
    use_log = color_scale == "log" and positive.size and positive.min() < positive.max()
    norm = LogNorm(vmin=positive.min(), vmax=positive.max()) if use_log else Normalize(0, 1)
    values = np.maximum(posterior, norm.vmin) if use_log else posterior
    colors = cmap(norm(np.ma.masked_invalid(values)))
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.7), layout="constrained")
    axes[0].bar(k, 100 * pos, color=colors)
    axes[0].set(title="Given a positive reference label", ylabel="Probability (%)")
    axes[1].bar(k, 100 * neg, color=colors)
    axes[1].set(title="Given a negative reference label")
    axes[2].plot(k, 100 * posterior, marker="o")
    limits = (float(positive.min()) * 80, 100) if use_log else (0, 100)
    axes[2].set(title="Hypothetical posterior", ylabel="Posterior (%)", ylim=limits)
    for ax in axes:
        ax.set_xlabel(f"Positive results out of {k[-1]}")
        if len(k) <= 25:
            ax.set_xticks(k)
        ax.grid(axis="y", alpha=0.3)
    fig.colorbar(ScalarMappable(norm=norm, cmap=cmap), ax=axes[:2],
                 orientation="horizontal", label="Posterior fraction")
    fig.savefig(output, dpi=180)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--confusion-matrix", type=Path,
                        default=ROOT / "artifacts" / "pretrained" / "confusion_matrix.joblib")
    parser.add_argument("--n-images", type=int, help="Hypothetical total; defaults to 9.")
    parser.add_argument("--predictions", type=Path, help="Read total and positive count from predict.py CSV.")
    parser.add_argument("--prevalence", type=float, default=0.032)
    parser.add_argument("--positive-count", type=int, help="Optional hypothetical count to highlight.")
    parser.add_argument("--color-scale", choices=("linear", "log"),
                        help="Defaults to log for a standalone example or linear for a prediction CSV.")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs")
    args = parser.parse_args()

    try:
        n_images = args.n_images if args.n_images is not None else 9
        count = args.positive_count
        if args.predictions is not None:
            if args.n_images is not None or count is not None:
                raise ValueError("--predictions cannot be combined with --n-images or --positive-count.")
            with args.predictions.open(encoding="utf-8", newline="") as file:
                reader = csv.DictReader(file)
                if "predicted_class" not in (reader.fieldnames or ()):
                    raise ValueError("Prediction CSV needs a predicted_class column.")
                labels = [row["predicted_class"] for row in reader]
            if any(label not in ("0", "1") for label in labels):
                raise ValueError("Predicted classes must be 0 or 1.")
            n_images, count = len(labels), labels.count("1")
        sensitivity, specificity = rates_from_confusion_matrix(joblib.load(args.confusion_matrix))
        k, pos, neg, posterior = posterior_curve(
            n_images, sensitivity, specificity, args.prevalence,
        )
        if count is not None and not 0 <= count <= n_images:
            raise ValueError("--positive-count must be between zero and --n-images.")
    except (ValueError, FileNotFoundError) as error:
        parser.exit(1, f"Bayesian analysis failed: {error}\n")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    with (args.output_dir / "bayes.csv").open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["positive_count", "likelihood_given_positive_label",
                         "likelihood_given_negative_label", "hypothetical_posterior"])
        writer.writerows(zip(k, pos, neg, posterior, strict=True))
    color_scale = args.color_scale or ("linear" if args.predictions is not None else "log")
    plot_curve(k, pos, neg, posterior, args.output_dir / "bayes.png", color_scale)

    _, a, b, post = posterior_curve(1, sensitivity, specificity, args.prevalence)
    print(f"Sensitivity: {sensitivity:.2%}; specificity: {specificity:.2%}")
    for i, label in enumerate(("negative", "positive")):
        print(f"One {label} result: joint shares = "
              f"{args.prevalence * a[i]:.2%} (positive label), "
              f"{(1 - args.prevalence) * b[i]:.2%} (negative label); "
              f"hypothetical posteriors = {post[i]:.2%} (positive label), "
              f"{1 - post[i]:.2%} (negative label)" if np.isfinite(post[i])
              else f"One {label} result: impossible under the model.")
    if count is not None:
        value = posterior[count]
        print(f"Hypothetical posterior for {count}/{n_images}: "
              + (f"{value:.2%}" if np.isfinite(value) else "undefined (impossible count)."))
    print(f"Wrote analysis to {args.output_dir}.")


if __name__ == "__main__":
    main()
