"""Align and crop eye strips from photos in Colab.

Usage: python scripts/crop.py INPUT_DIRECTORY OUTPUT_DIRECTORY
Keep detector settings, affine alignment, and OpenCV JPEG encoding in this
script. Use a fresh output directory for a new batch.
"""

import sys
from pathlib import Path
import math
import csv
import urllib.request
import cv2
import mediapipe as mp
import matplotlib.pyplot as plt
import numpy as np

# Input and output directories are passed on the command line.
INPUT_DIR = Path(sys.argv[1])
OUTPUT_DIR = Path(sys.argv[2])

# More padding includes more eyebrow/temple area.
PAD_X = 0.20  # fraction of eye-box width on each side
PAD_Y = 0.65  # fraction of eye-box height above and below

# False keeps the largest detected face in each photo.
ALL_FACES = False
NUM_FACES_TO_DETECT = 5
MIN_DETECTION_CONFIDENCE = 0.35
MIN_FACE_PRESENCE_CONFIDENCE = 0.35
IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp'}

if not INPUT_DIR.exists():
    raise FileNotFoundError(f'Input folder not found: {INPUT_DIR}')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
print(f'Input:  {INPUT_DIR}')
print(f'Output: {OUTPUT_DIR}')

# Download Google's Face Landmarker model file once into the Colab runtime.
MODEL_PATH = Path('/content/face_landmarker.task')
MODEL_URL = (
    'https://storage.googleapis.com/mediapipe-models/face_landmarker/'
    'face_landmarker/float16/1/face_landmarker.task'
)
if not MODEL_PATH.exists():
    urllib.request.urlretrieve(MODEL_URL, MODEL_PATH)

BaseOptions = mp.tasks.BaseOptions
FaceLandmarker = mp.tasks.vision.FaceLandmarker
FaceLandmarkerOptions = mp.tasks.vision.FaceLandmarkerOptions
RunningMode = mp.tasks.vision.RunningMode

options = FaceLandmarkerOptions(
    base_options=BaseOptions(model_asset_path=str(MODEL_PATH)),
    running_mode=RunningMode.IMAGE,
    num_faces=NUM_FACES_TO_DETECT,
    min_face_detection_confidence=MIN_DETECTION_CONFIDENCE,
    min_face_presence_confidence=MIN_FACE_PRESENCE_CONFIDENCE,
)
landmarker = FaceLandmarker.create_from_options(options)
print('Face Landmarker is ready.')

MIN_EAR = 0.21  # Raise to require wider-open eyes; tune by inspecting examples.

def eye_aspect_ratio(face_landmarks, image_shape, corners, vertical_pairs):
    height, width = image_shape[:2]

    def xy(index):
        point = face_landmarks[index]
        return (point.x * width, point.y * height)

    def distance(index_a, index_b):
        x1, y1 = xy(index_a)
        x2, y2 = xy(index_b)
        return math.hypot(x2 - x1, y2 - y1)

    eye_width = distance(*corners)
    if eye_width < 1e-6:
        return 0.0

    vertical_opening = sum(distance(a, b) for a, b in vertical_pairs)
    return vertical_opening / (2 * eye_width)

def eyes_are_open(face_landmarks, image_shape):
    left_ear = eye_aspect_ratio(
        face_landmarks, image_shape,
        corners=(33, 133),
        vertical_pairs=((160, 144), (158, 153)),
    )
    right_ear = eye_aspect_ratio(
        face_landmarks, image_shape,
        corners=(362, 263),
        vertical_pairs=((385, 380), (387, 373)),
    )

    # Require both eyes to be open.
    return left_ear >= MIN_EAR and right_ear >= MIN_EAR

import math
import cv2

# MediaPipe iris-center landmark indices.
LEFT_IRIS_CENTER = 468
RIGHT_IRIS_CENTER = 473

CROP_WIDTH = 128
CROP_HEIGHT = 20
EYE_SPACING_RATIO = 0.7

def eye_centers(face_landmarks, image_shape):
    # Iris landmarks require a 478-landmark face mesh.
    if len(face_landmarks) <= RIGHT_IRIS_CENTER:
        return None

    height, width = image_shape[:2]
    centers = [
        [
            face_landmarks[i].x * width,
            face_landmarks[i].y * height,
        ]
        for i in (LEFT_IRIS_CENTER, RIGHT_IRIS_CENTER)
    ]

    # Sort by image x-coordinate so mirrored photos still align upright.
    return sorted(centers, key=lambda point: point[0])

def aligned_eye_crop(image, face_landmarks):
    centers = eye_centers(face_landmarks, image.shape)
    if centers is None:
        return None

    (x1, y1), (x2, y2) = centers
    eye_distance = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
    if eye_distance < CROP_WIDTH*EYE_SPACING_RATIO:
        return None

    # Rotate and scale around the midpoint between the iris centers.
    midpoint = ((x1 + x2) / 2, (y1 + y2) / 2)
    angle_degrees = math.degrees(math.atan2(y2 - y1, x2 - x1))
    target_eye_distance = CROP_WIDTH * EYE_SPACING_RATIO
    scale = target_eye_distance / eye_distance
    matrix = cv2.getRotationMatrix2D(midpoint, angle_degrees, scale)

    # Move the midpoint between the irises to the output crop center.
    matrix[0, 2] += CROP_WIDTH / 2 - midpoint[0]
    matrix[1, 2] += CROP_HEIGHT / 2 - midpoint[1]

    return cv2.warpAffine(
        image,
        matrix,
        (CROP_WIDTH, CROP_HEIGHT),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_REFLECT_101,
    )

def face_area(face_landmarks, image_shape):
    height, width = image_shape[:2]
    xs = [point.x * width for point in face_landmarks]
    ys = [point.y * height for point in face_landmarks]
    return (max(xs) - min(xs)) * (max(ys) - min(ys))

def find_faces(image):
    rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
    result = landmarker.detect(mp_image)
    return result.face_landmarks

from glasses_detector import GlassesClassifier

classifier = GlassesClassifier()


image_paths = sorted(
    p for p in INPUT_DIR.rglob('*')
    if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS
)
print(f'Found {len(image_paths)} image(s).')

saved_count = 0
no_face_paths = []
failed_paths = []

for i, path in enumerate(image_paths, start=1):
    # Keep the input folder structure in the output folder.
    relative_parent = path.parent.relative_to(INPUT_DIR)
    output_folder = OUTPUT_DIR / relative_parent
    output_folder.mkdir(parents=True, exist_ok=True)

    image = cv2.imread(str(path))
    if image is None:
        failed_paths.append((str(path), 'Could not read image'))
        continue

    has_glasses = classifier(path, format="bool")
    if has_glasses:
        failed_paths.append((str(path), 'Glasses'))
        print("Glasses")
        continue

    faces = find_faces(image)
    if not faces:
        no_face_paths.append(str(path))
        continue

    faces = sorted(faces, key=lambda f: face_area(f, image.shape), reverse=True)
    selected_faces = faces if ALL_FACES else faces[:1]

    for face_index, face in enumerate(selected_faces, start=1):
        if not eyes_are_open(face, image.shape):
            failed_paths.append((str(path), 'Eyes closed or too narrow'))
            continue

        crop = aligned_eye_crop(image, face)
        if crop is None:
            failed_paths.append((str(path), 'Could not create crop'))
            continue

        gray_crop = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        suffix = f'_eyes_face{face_index}' if ALL_FACES else '_eyes'
        output_path = output_folder / f'{path.stem}{suffix}.jpg'

        if cv2.imwrite(str(output_path), gray_crop):
            saved_count += 1
        else:
            failed_paths.append((str(path), 'Could not save crop'))

    if i % 25 == 0 or i == len(image_paths):
        print(f'Processed {i}/{len(image_paths)} images...')

# Save a list of files that need manual review.
review_csv = OUTPUT_DIR / 'detection_review.csv'
with review_csv.open('w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['image_path', 'issue'])
    writer.writerows((p, 'No face detected') for p in no_face_paths)
    writer.writerows(failed_paths)

print(f'\nCrops saved: {saved_count}')
print(f'Images with no detected face: {len(no_face_paths)}')
print(f'Unreadable/failed images: {len(failed_paths)}')
print(f'Review list: {review_csv}')
