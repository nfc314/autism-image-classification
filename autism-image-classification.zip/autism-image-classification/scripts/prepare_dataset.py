"""Organize a downloaded dataset ZIP without changing its split assignments."""

import argparse
from collections import Counter
from pathlib import Path, PurePosixPath
from shutil import copyfileobj
from stat import S_ISLNK
from tempfile import TemporaryDirectory, TemporaryFile
from zipfile import BadZipFile, ZipFile

ROOT = Path(__file__).resolve().parent.parent
SPLITS = {
    "train": "Training Data", "training": "Training Data", "trainingdata": "Training Data",
    "traindata": "Training Data", "test": "Test", "testdata": "Test", "testing": "Test",
    "testingdata": "Test", "val": "Validation Data", "valid": "Validation Data",
    "validation": "Validation Data", "validationdata": "Validation Data",
    "validdata": "Validation Data", "valdata": "Validation Data",
}
CLASSES = {
    "autistic": "Autistic", "autism": "Autistic",
    "nonautistic": "Non-Autistic", "nonautism": "Non-Autistic",
    "notautistic": "Non-Autistic", "notautism": "Non-Autistic",
}
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
MAX_TOTAL_BYTES = 2 * 1024**3
MAX_IMAGE_BYTES = 32 * 1024**2
MAX_ENTRIES = 10_000


def key(part):
    return "".join(char for char in part.casefold() if char.isalnum())


def safe_parts(info):
    name = info.filename.replace("\\", "/")
    parts = name.split("/")
    if (len(parts) > 32 or len(name) > 1024 or
        any(not part or part in (".", "..") or part.endswith((" ", ".")) or
            any(c in '<>:"|?*' or ord(c) < 32 for c in part) or
            part.split(".")[0].upper() in (
                {"CON", "PRN", "AUX", "NUL"} |
                {f"{prefix}{i}" for prefix in ("COM", "LPT") for i in range(1, 10)}
            ) for part in parts) or
        S_ISLNK(info.external_attr >> 16)):
        raise ValueError("The ZIP contains an unsafe file path. Use the original dataset download.")
    return tuple(parts)


def normalized_destination(parts):
    folders = parts[:-1]
    found = set()
    for i, name in enumerate(folders[:-1]):
        a, b = key(name), key(folders[i + 1])
        if a in SPLITS and b in CLASSES:
            found.add((SPLITS[a], CLASSES[b], *parts[i + 2:]))
        if a in CLASSES and b in SPLITS:
            found.add((SPLITS[b], CLASSES[a], *parts[i + 2:]))
    if len(found) > 1:
        raise ValueError("An image path has ambiguous split and class folder names.")
    if found:
        return PurePosixPath(*found.pop())
    return None


def plan_entries(archive, prefix=()):
    images, inner = [], []
    contents = archive.infolist()
    if len(contents) > MAX_ENTRIES:
        raise ValueError(f"ZIP exceeds the {MAX_ENTRIES:,}-entry safety limit.")
    for info in contents:
        if info.is_dir():
            continue
        parts = safe_parts(info)
        if any(part.startswith(".") or part == "__MACOSX" for part in parts):
            continue
        suffix = PurePosixPath(parts[-1]).suffix.lower()
        if suffix == ".zip":
            inner.append(info)
        if suffix not in IMAGE_EXTENSIONS:
            continue
        dest = normalized_destination((*prefix, *parts))
        if dest is not None:
            images.append((info, dest))
        elif any(key(folder) in SPLITS for folder in (*prefix, *parts[:-1])):
            raise ValueError(
                "An image inside a train/test/validation folder has no recognized class folder. "
                "Use Autistic and Non-Autistic class folders from the original download."
            )
        # Ignore extra image collections outside the three defined splits.
    return images, inner


def validate_plan(images):
    counts, seen = Counter(), set()
    total = 0
    for info, dest in images:
        total += info.file_size
        if info.file_size > MAX_IMAGE_BYTES or total > MAX_TOTAL_BYTES:
            raise ValueError("ZIP exceeds the extraction size limit.")
        k = dest.as_posix().casefold()
        if k in seen:
            raise ValueError("Two images map to the same destination. Nothing was extracted.")
        seen.add(k)
        counts[dest.parts[:2]] += 1
    for split in ("Training Data", "Test", "Validation Data"):
        for label in ("Autistic", "Non-Autistic"):
            if not counts[split, label]:
                raise ValueError(
                    f"The archive did not provide images for {split}/{label}. "
                    "Use Download All on the Mendeley dataset page, not a single split."
                )
    return counts


def extract_images(archive, images, output):
    counts = validate_plan(images)
    output.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".dataset-", dir=output.parent) as stage:
        folder = Path(stage) / "ready"
        for info, relative in images:
            target = folder.joinpath(*relative.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, target.open("xb") as file:
                copyfileobj(source, file)
        if output.exists() or output.is_symlink():
            raise FileExistsError(f"Output already exists: {output}")
        folder.rename(output)
    return counts


def prepare_dataset(download, output):
    if output.exists() or output.is_symlink():
        raise FileExistsError(
            f"Output already exists: {output}. Choose an unused --output folder."
        )
    with ZipFile(download) as archive:
        images, inner = plan_entries(archive)
        if images or not inner:
            return extract_images(archive, images, output)
        if len(inner) != 1:
            raise ValueError("Expected the three dataset folders or one dataset ZIP inside the download.")
        member = inner[0]
        if member.file_size > MAX_TOTAL_BYTES:
            raise ValueError("Nested ZIP exceeds the extraction size limit.")
        with TemporaryFile() as content, archive.open(member) as source:
            copyfileobj(source, content)
            content.seek(0)
            with ZipFile(content) as nested:
                images, _ = plan_entries(nested)
                return extract_images(nested, images, output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path, help="ZIP from the dataset's Download All button.")
    parser.add_argument("--output", type=Path, default=ROOT / "data" / "Unprocessed Data",
                        help="New output folder; defaults to data/Unprocessed Data under the project root.")
    args = parser.parse_args()
    output = args.output.expanduser()
    try:
        counts = prepare_dataset(args.archive.expanduser(), output)
    except (OSError, BadZipFile, ValueError, RuntimeError) as error:
        parser.exit(1, f"Could not prepare the dataset: {error}\n")

    print(f"Prepared {sum(counts.values()):,} local images in {output}")
    for split in ("Training Data", "Test", "Validation Data"):
        print(f"  {split}: {counts[split, 'Autistic']:,} Autistic, "
              f"{counts[split, 'Non-Autistic']:,} Non-Autistic")


if __name__ == "__main__":
    main()
