"""Feature extraction shared by training and prediction."""
from pathlib import Path
from typing import BinaryIO, Sequence

import numpy as np
from PIL import Image

DEFAULT_IMAGE_SHAPE = (20, 128)  # height, width
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}


def image_paths(path: Path) -> list[Path]:
    path = Path(path)
    if path.is_file():
        if path.suffix.lower() not in IMAGE_EXTENSIONS:
            raise ValueError(f"Unsupported image extension: {path.suffix}")
        return [path]
    if not path.is_dir():
        raise FileNotFoundError(f"Input does not exist: {path}")
    return sorted(p for p in path.rglob("*")
                  if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS)


def read_feature_row(
    source: Path | BinaryIO, expected_shape: tuple[int, int] | None = None,
    *, name: str | Path | None = None,
) -> tuple[np.ndarray, tuple[int, int]]:
    """Read the same grayscale features from a path or an in-memory encoded image."""
    name = source if name is None else name
    with Image.open(source) as image:
        pixels = np.asarray(image.convert("L"), dtype=np.float32)
    shape = pixels.shape
    if expected_shape is not None and shape != expected_shape:
        raise ValueError(f"{name}: got image shape {shape}, expected {expected_shape} (H, W).")
    average = pixels.mean()
    if average <= 0:
        raise ValueError(f"{name}: all-black eye strip cannot be brightness-normalized.")
    return (pixels / average).ravel(), shape


def load_features(
    paths: Sequence[Path], expected_shape: tuple[int, int] | None = None,
) -> tuple[np.ndarray, tuple[int, int]]:
    if not paths:
        raise ValueError("No images to load.")
    rows = []
    shape = expected_shape
    for path in paths:
        row, shape = read_feature_row(path, shape)
        rows.append(row)
    assert shape is not None
    return np.stack(rows), shape
