"""Score one raw photo or a folder for the image classification experiment."""
import argparse
import csv
from io import BytesIO
from pathlib import Path
import sys

import joblib
import numpy as np

from features import image_paths, load_features, read_feature_row
from model import FORMAT_VERSION, MODEL_FILENAME, PCA_FILENAME, SCALER_FILENAME, SCORE_THRESHOLD

ROOT = Path(__file__).resolve().parent.parent
SAVED_MODEL_FILENAMES = ("pretrained_model.pt", "Learned Model Full", "Learned Model Full.zip")


def load_model(artifacts_dir: Path, legacy_model: Path | None):
    import torch
    from model import build_model

    if legacy_model is not None:
        # Whole-model loading is available only when the caller explicitly opts in.
        net = torch.load(legacy_model, map_location="cpu", weights_only=False)
        if not isinstance(net, torch.nn.Module):
            raise ValueError("The supplied file is not a saved PyTorch model.")
        return net.eval(), None

    checkpoint = torch.load(artifacts_dir / MODEL_FILENAME, map_location="cpu", weights_only=True)
    if checkpoint.get("format_version") != FORMAT_VERSION:
        raise ValueError("Unrecognized model.pt checkpoint format.")
    net = build_model(checkpoint["num_inputs"], checkpoint["hidden_units"])
    net.load_state_dict(checkpoint["state_dict"])
    return net.eval(), tuple(checkpoint["image_shape"])


def resolve_legacy_model(artifacts_dir: Path, option: str | None) -> Path | None:
    if option is None:
        return None
    if option:
        return Path(option).expanduser()
    return next((artifacts_dir / name for name in SAVED_MODEL_FILENAMES
                 if (artifacts_dir / name).is_file()),
                artifacts_dir / SAVED_MODEL_FILENAMES[0])


def input_root(input_path: Path) -> Path:
    return input_path.parent if input_path.is_file() else input_path


def raw_features(input_path: Path, model_path: Path | None, shape):
    """Crop and JPEG-round-trip in memory; the raw-photo path saves no images."""
    from preprocess import encode_gray_crop, iter_crops

    base = input_root(input_path)
    records = []
    used = set()
    for outcome in iter_crops(input_path, model_path=model_path):
        relative = outcome.source_path.relative_to(base)
        if outcome.crop is None:
            print(f"Skipped {relative}: {outcome.issue}", file=sys.stderr)
            continue
        content = encode_gray_crop(outcome.crop)
        if content is None:
            print(f"Skipped {relative}: could not encode eye strip", file=sys.stderr)
            continue

        # Preserve the JPEG round-trip before Pillow normalization. Bypassing
        # JPEG would change pixels and therefore could change features and scores.
        row, shape = read_feature_row(BytesIO(content), shape, name=relative)
        virtual_crop = relative.with_name(f"{relative.stem}_eyes.jpg")
        count = 2
        while virtual_crop.as_posix().casefold() in used:
            virtual_crop = relative.with_name(f"{relative.stem}_{count}_eyes.jpg")
            count += 1
        used.add(virtual_crop.as_posix().casefold())
        records.append((virtual_crop, outcome.source_path, row))
    if not records:
        raise ValueError("No usable eye strips. See skipped-photo messages above.")
    # Use a stable, case-sensitive order for the generated JPEG names.
    records.sort(key=lambda record: record[0].parts)
    names, sources, rows = zip(*records, strict=True)
    return np.stack(rows), sources, names


def score_features(features, net, pca, scaler):
    """Apply the fitted transforms, score the network and threshold the sigmoid."""
    import torch

    transformed = scaler.transform(pca.transform(features)).astype("float32")
    with torch.inference_mode():
        scores = torch.sigmoid(net(torch.from_numpy(transformed))).cpu().numpy().ravel()
    return scores, (scores >= SCORE_THRESHOLD).astype(int)


def predict(args):
    net, shape = load_model(args.artifacts_dir, args.trusted_legacy_model)
    pca = joblib.load(args.artifacts_dir / PCA_FILENAME)
    scaler = joblib.load(args.artifacts_dir / SCALER_FILENAME)
    if args.cropped:
        sources = names = sorted(
            (path for path in image_paths(args.input) if path.suffix.lower() != ".webp"),
            key=lambda path: path.parts,
        )
        features, _ = load_features(sources, shape)
    else:
        features, sources, names = raw_features(args.input, args.landmarker_model, shape)
    scores, classes = score_features(features, net, pca, scaler)

    base = input_root(args.input).absolute()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["image", "class_1_probability", "predicted_class", "source_image"])
        for source, crop, score, label in zip(sources, names, scores, classes, strict=True):
            relative = source.absolute().relative_to(base).as_posix()
            writer.writerow([crop.name, f"{float(score):.9g}", int(label), relative])
    print(f"Wrote {len(scores)} research scores to {args.output}.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Path to one image or an image directory.")
    parser.add_argument("--artifacts-dir", type=Path, default=ROOT / "artifacts" / "pretrained")
    parser.add_argument("--output", type=Path, default=ROOT / "outputs" / "predictions.csv")
    parser.add_argument("--landmarker-model", type=Path, help="Existing MediaPipe Face Landmarker asset.")
    parser.add_argument("--cropped", action="store_true", help="Input already contains aligned eye strips.")
    parser.add_argument("--trusted-saved-model", "--trusted-legacy-model",
                        dest="trusted_legacy_model", nargs="?", const="", metavar="PATH",
                        help="Opt into pickle loading for a trusted whole-model file. "
                             "Defaults to pretrained_model.pt in --artifacts-dir if no path is supplied.")
    args = parser.parse_args()
    args.input = args.input.expanduser()
    args.artifacts_dir = args.artifacts_dir.expanduser()
    args.output = args.output.expanduser()
    args.trusted_legacy_model = resolve_legacy_model(args.artifacts_dir, args.trusted_legacy_model)
    try:
        predict(args)
    except (OSError, ValueError, ImportError) as error:
        parser.exit(1, f"Prediction failed: {error}\n")


if __name__ == "__main__":
    main()
