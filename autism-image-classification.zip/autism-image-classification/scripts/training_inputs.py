"""Extract only Training/Validation and check them against the fixed Test strips."""

import argparse
from collections import Counter
from hashlib import sha256
from pathlib import Path, PurePosixPath
from shutil import copyfileobj
from tempfile import TemporaryDirectory, TemporaryFile
from zipfile import BadZipFile, ZipFile

from prepare_dataset import (
    CLASSES, IMAGE_EXTENSIONS, MAX_ENTRIES, MAX_IMAGE_BYTES, MAX_TOTAL_BYTES,
    SPLITS, key, normalized_destination, safe_parts,
)

FIT_SPLITS = {"Training Data", "Validation Data"}
CROPPED_EXTENSIONS = IMAGE_EXTENSIONS - {".webp"}


def destination(parts, hint):
    # Do not reinterpret an explicit Test folder as Train or Validation.
    labels = {SPLITS[key(part)] for part in parts[:-1] if key(part) in SPLITS}
    if "Test" in labels:
        return None
    dest = normalized_destination(parts)
    if dest is not None:
        if hint is not None and dest.parts[0] != hint:
            raise ValueError("An inner split ZIP contains another split's files.")
        return dest
    if hint:
        for i, part in enumerate(parts[:-1]):
            label = CLASSES.get(key(part))
            if label:
                return PurePosixPath(hint, label, *parts[i + 1:])
    if labels & FIT_SPLITS:
        raise ValueError("Place Training and Validation images in labeled class folders.")
    return None


def extract_fit_splits(archive, output, extensions, hint=None, depth=0, state=None):
    if state is None:
        state = {"count": Counter(), "seen": set(), "bytes": 0, "entries": 0}
    members = archive.infolist()
    state["entries"] += len(members)
    if len(members) > MAX_ENTRIES or state["entries"] > 2 * MAX_ENTRIES:
        raise ValueError("The archive exceeds the file-count limit.")
    named = []
    unknown = []
    for info in members:
        if info.is_dir():
            continue
        parts = safe_parts(info)
        if any(part.startswith(".") or part == "__MACOSX" for part in parts):
            continue
        if any(SPLITS.get(key(p)) == "Test" for p in parts[:-1]):
            continue
        suffix = PurePosixPath(parts[-1]).suffix.lower()
        if suffix == ".zip":
            other = SPLITS.get(key(PurePosixPath(parts[-1]).stem))
            if other == "Test":
                continue
            if other in FIT_SPLITS:
                named.append((info, other))
            elif hint is None:
                unknown.append(info)
            continue
        if suffix not in extensions:
            continue
        target = destination(parts, hint)
        if target is None or target.parts[0] not in FIT_SPLITS:
            continue
        name = target.as_posix().casefold()
        if name in state["seen"]:
            raise ValueError("Multiple images resolve to the same training destination.")
        state["seen"].add(name)
        state["bytes"] += info.file_size
        if info.file_size > MAX_IMAGE_BYTES or state["bytes"] > MAX_TOTAL_BYTES:
            raise ValueError("The training images exceed the extraction size limit.")
        path = output.joinpath(*target.parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        with archive.open(info) as src, path.open("xb") as dst:
            copyfileobj(src, dst)
        state["count"][target.parts[:2]] += 1

    # Support split ZIPs (Train.zip, Val.zip), and a single wrapper ZIP.
    children = named
    if not children and not state["count"] and len(unknown) == 1:
        children = [(unknown[0], None)]
    if children and depth >= 2:
        raise ValueError("The training archive is nested too deeply.")
    for info, split in children:
        if info.file_size > MAX_TOTAL_BYTES:
            raise ValueError("A nested archive exceeds the extraction size limit.")
        with TemporaryFile() as content, archive.open(info) as src:
            copyfileobj(src, content)
            content.seek(0)
            with ZipFile(content) as child:
                extract_fit_splits(child, output, extensions, split, depth + 1, state)
    return state["count"]


def prepare_fit_inputs(path, output, *, cropped):
    if output.exists():
        raise ValueError("Choose a fresh directory for training inputs.")
    output.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".training-", dir=output.parent) as working:
        stage = Path(working) / "ready"
        with ZipFile(path) as archive:
            counts = extract_fit_splits(
                archive, stage, CROPPED_EXTENSIONS if cropped else IMAGE_EXTENSIONS
            )
        for split in FIT_SPLITS:
            for label in ("Autistic", "Non-Autistic"):
                if not counts[split, label]:
                    raise ValueError(f"Missing images for {split}/{label}.")
        stage.rename(output)
    return counts


def gray_digest(stream):
    """Check exact decoded grayscale pixels, including alternate lossless encodings."""
    from PIL import Image

    with Image.open(stream) as image:
        gray = image.convert("L")
        if gray.size != (128, 20):
            raise ValueError("Expected pre-cropped eye strips measuring 128 x 20 pixels.")
        return sha256(gray.tobytes()).digest()


def reject_exact_test_overlap(crops, fixed_archive):
    with ZipFile(fixed_archive) as archive:
        hashes = set()
        for info in archive.infolist():
            if info.is_dir():
                continue
            parts = safe_parts(info)
            if len(parts) >= 3 and SPLITS.get(key(parts[0])) == "Test" and (
                PurePosixPath(parts[-1]).suffix.lower() in CROPPED_EXTENSIONS
            ):
                if info.file_size > MAX_IMAGE_BYTES:
                    raise ValueError("A fixed Test image exceeds the extraction size limit.")
                with archive.open(info) as src:
                    hashes.add(gray_digest(src))
    if not hashes:
        raise ValueError("The bundled Test archive contains no recognized Test eye strips.")
    for split in sorted(FIT_SPLITS):
        for path in (crops / split).rglob("*"):
            if path.is_file() and path.suffix.lower() in CROPPED_EXTENSIONS:
                with path.open("rb") as src:
                    duplicate = gray_digest(src) in hashes
                if duplicate:
                    raise ValueError(
                        f"{split} contains an exact copy of a bundled Test strip. "
                        "Correct your data split before retraining."
                    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("raw", "cropped", "check-holdout"))
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    try:
        if args.mode == "check-holdout":
            reject_exact_test_overlap(args.source, args.destination)
            print("No exact pixel duplicates of the bundled Test strips were found in the fit splits.")
        else:
            counts = prepare_fit_inputs(args.source, args.destination, cropped=args.mode == "cropped")
            for split in ("Training Data", "Validation Data"):
                print(f"{split}: {sum(counts[split, name] for name in set(CLASSES.values())):,} images.")
            print("The archive’s Test split was not extracted or used.")
    except (BadZipFile, OSError, ValueError, RuntimeError) as error:
        parser.exit(1, f"Could not prepare training inputs: {error}\n")


if __name__ == "__main__":
    main()
