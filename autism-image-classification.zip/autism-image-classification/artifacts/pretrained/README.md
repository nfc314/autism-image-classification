# Included trained model

- [`pretrained_model.pt`](pretrained_model.pt) contains the trained PyTorch network.
- [`pca.joblib`](pca.joblib) and [`scaler.joblib`](scaler.joblib) hold the fitted feature transformations. They were saved with scikit-learn 1.6.1.
- [`confusion_matrix.joblib`](confusion_matrix.joblib) holds the network’s counts on the bundled test set. Cell 6 uses them for the Bayesian example when you choose **Saved project model**.

Keep these files together. Only load model and joblib files from sources you trust; the included network is a whole-model PyTorch checkpoint. Running Cell 3 does not overwrite these files.
